require("dotenv").config();
const path = require("path");
const express = require("express");
const helmet = require("helmet");
const cookieParser = require("cookie-parser");

for (const k of ["SUPABASE_URL", "SUPABASE_SERVICE_ROLE_KEY", "JWT_SECRET"]) {
  if (!process.env[k]) {
    console.error(`Missing ${k} in backend/.env`);
    process.exit(1);
  }
}

const app = express();
app.use(helmet());
app.use(express.json({ limit: "10kb" }));
app.use(cookieParser());

app.get("/api/health", (req, res) => res.json({ status: "ok" }));
app.use("/api/auth", require("./routes/auth"));
app.use("/api/events", require("./routes/events"));
app.use("/api/bookings", require("./routes/bookings"));
app.use("/api", (req, res) => res.status(404).json({ error: "Not found" }));

app.use(express.static(path.join(__dirname, "..", "frontend")));

// Central error handler: never leaks stack traces or database details
app.use((err, req, res, next) => {
  if (err.status === 400) return res.status(400).json({ error: "Invalid request" });
  console.error(err.message);
  res.status(500).json({ error: "Something went wrong on the server" });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
